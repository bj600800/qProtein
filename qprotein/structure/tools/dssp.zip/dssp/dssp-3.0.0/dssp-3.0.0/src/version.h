#ifndef version_h
#define version_h

#define XSSP_VERSION "3.0.0"

#endif
