This README is part of the source code distribution of DSSP 3.0

To build the mkdssp executable, you need a recent C++ compiler
capable of compiling C++0x code. You also need a recent version
of the Boost libraries, we are currently using version 1.62.0.

The makefile reads a make.config file containing site specific
settings. This make.config file is created if it doesn't exist
when running make.

Please let me know if there are any problems with this code.
You can reach me at: mailto:coos.baakman@radboudumc.nl

-Coos Baakman
