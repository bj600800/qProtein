README file for the Misc folder.
==================================================================

A collection of PQR files of molecules with interesting potentials

|                        |                                      |
|------------------------|--------------------------------------|
| [fas2.pqr](fas2.pqr)   | Fasciculin-2 (1FSC)                  |
| [mache.pqr](mache.pqr) | Mouse acetylcholinesterase (1MAH)    |
| [achbp.pqr](achbp.pqr) | Acetylcholine binding protein (1I9B) |

