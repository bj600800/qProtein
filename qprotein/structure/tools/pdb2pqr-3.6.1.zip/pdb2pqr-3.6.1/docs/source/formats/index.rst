============
File formats
============

---------------------------
Molecular structure formats
---------------------------

.. toctree::
   :maxdepth: 1

   pqr
   pdb
   mol2

-----------------
Parameter formats
-----------------

.. toctree::
   :maxdepth: 1

   xml-names
   dat
