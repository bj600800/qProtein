.. _pdb:

PDB molecular structure format
==============================

The PDB file format is described in detail in the `Protein Data Bank documentation <http://www.rcsb.org/pdb/static.do?p=file_formats/pdb/index.html>`_.
